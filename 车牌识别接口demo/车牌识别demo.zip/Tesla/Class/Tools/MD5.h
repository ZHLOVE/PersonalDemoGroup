//
//  MD5.h
//  SafeDarkVC
//
//  Created by MBP on 16/6/19.
//  Copyright © 2016年 leqi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MD5 : NSObject

+(NSString *) md5: (NSString *) inPutText;

@end
