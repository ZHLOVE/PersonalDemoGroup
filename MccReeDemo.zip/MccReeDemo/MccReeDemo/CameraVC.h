//
//  CameraVC.h
//  Blink
//
//  Created by MBP on 2016/12/28.
//  Copyright © 2016年 leqi. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CameraVC : UIViewController

- (UIImage *)grayImageFromImage:(UIImage *)oriImage;


@end
