//
//  MRVC.m
//  MccReeDemo
//
//  Created by MccRee on 2017/8/5.
//  Copyright © 2017年 MccRee. All rights reserved.
//

#import "MRVC.h"
#import "CameraVC.h"

#define W [UIScreen mainScreen].bounds.size.width
#define H [UIScreen mainScreen].bounds.size.height
@interface MRVC ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>



@property(nonatomic,strong) UIButton *photoBtn;
@property(nonatomic,strong) UIButton *cameraBtn;
@property(nonatomic,strong) UIImageView *imgView;

@property(nonatomic,strong) UIImagePickerController *imagePicker;

@end

@implementation MRVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.photoBtn];
    [self.view addSubview:self.cameraBtn];
    [self.view addSubview:self.imgView];
}






//选择完图片后会回调 didFinishPickingMediaWithInfo 这个方法
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    CameraVC *cam = [[CameraVC alloc]init];
    UIImage *oriImg = info[@"UIImagePickerControllerOriginalImage"];
    [self.imgView setImage:[cam grayImageFromImage:oriImg]];
    [picker dismissViewControllerAnimated:YES completion:nil];
}





//导航条上面的 Cancel 的点击方法
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}



- (void)gotoPhoto{
    [self presentViewController:self.imagePicker animated:YES completion:nil];
}

- (void)gotoCamera{
    CameraVC *cam = [[CameraVC alloc]init];
    [self.navigationController pushViewController:cam animated:YES];
}






- (UIButton *)photoBtn{
    if (!_photoBtn) {
        _photoBtn = [[UIButton alloc]initWithFrame:CGRectMake(20, 100, 100, 40)];
        [_photoBtn setTitle:@"相册" forState:UIControlStateNormal];
        _photoBtn.backgroundColor = [UIColor lightGrayColor];
        [_photoBtn addTarget:self action:@selector(gotoPhoto) forControlEvents:UIControlEventTouchUpInside];

    }
    return _photoBtn;
}

- (UIButton *)cameraBtn{
    if (!_cameraBtn) {
        _cameraBtn = [[UIButton alloc]initWithFrame:CGRectMake(W-120, 100, 100,40)];
        [_cameraBtn setTitle:@"摄像头" forState:UIControlStateNormal];
        _cameraBtn.backgroundColor = [UIColor lightGrayColor];
        [_cameraBtn addTarget:self action:@selector(gotoCamera) forControlEvents:UIControlEventTouchUpInside];
    }
    return _cameraBtn;
}

- (UIImageView *)imgView{
    if (!_imgView) {
        _imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, H-W, W, W)];
        _imgView.layer.borderWidth = 1;
        _imgView.layer.borderColor = [UIColor blackColor].CGColor;
        _imgView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _imgView;
}

- (UIImagePickerController *)imagePicker{
    if (!_imagePicker) {
        _imagePicker = [[UIImagePickerController alloc] init];
        _imagePicker.delegate = self;
        _imagePicker.allowsEditing = YES;
        UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        _imagePicker.sourceType = sourceType;
    }
    return _imagePicker;
}

@end
