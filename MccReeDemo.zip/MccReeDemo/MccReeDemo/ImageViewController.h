//
//  ImageViewController.h
//  Blink
//
//  Created by MBP on 2016/12/29.
//  Copyright © 2016年 leqi. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ImageViewController : UIViewController

- (instancetype)initWithImage:(UIImage *)image;


@end
