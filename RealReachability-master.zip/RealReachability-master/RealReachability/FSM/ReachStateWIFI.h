//
//  ReachStateWIFI.h
//  RealReachability
//
//  Created by Dustturtle on 16/1/19.
//  Copyright © 2016 Dustturtle. All rights reserved.
//

#import "ReachState.h"

@interface ReachStateWIFI : ReachState

@end
