//
//  ReachStateLoading.h
//  RealReachability
//
//  Created by Dustturtle on 16/1/9.
//  Copyright (c) 2016 Dustturtle. All rights reserved.
//

#import "ReachState.h"

@interface ReachStateLoading : ReachState

@end
