//
//  LangungeTableViewCell.h
//  11402PresidentList
//
//  Created by 马千里 on 16/3/10.
//  Copyright © 2016年 马千里. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LangungeTableViewCell : UITableViewCell

@end
