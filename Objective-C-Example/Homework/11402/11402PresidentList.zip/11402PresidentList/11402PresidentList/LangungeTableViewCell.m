//
//  LangungeTableViewCell.m
//  11402PresidentList
//
//  Created by 马千里 on 16/3/10.
//  Copyright © 2016年 马千里. All rights reserved.
//

#import "LangungeTableViewCell.h"

@implementation LangungeTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
